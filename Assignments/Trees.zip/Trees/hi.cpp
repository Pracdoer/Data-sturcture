#include <iostream>

#include <cmath>
using namespace std;

int  main()
{
	cout << pow(2,0); 
	return 0;
}