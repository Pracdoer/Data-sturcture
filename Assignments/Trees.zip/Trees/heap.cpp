#include <iostream>
#include <cmath>
using namespace std;

struct node
{
    int data;
    int lh;
    node *left, *right;
};

class heap
{
private:
    node *temp, *temp2;
public:
    node *root;
    int h, n_count, num;
    bool flag;
    heap()
    {
        root = temp = temp2 = NULL;
        n_count = 0;
    }

    int height(node *temp) {
    if (!temp) return -1;

    return 1 + max(height(temp->left), height(temp->right));
    }


    void travere(node *temp)
    {
        if(temp->left != NULL)
            travere(temp->left);
        cout << temp->data << "  " ;
        //return temp;
        if(temp->right != NULL)
            travere(temp->right);
    }

    void insert(node *temp, int value)
    {
        if(root == NULL)
        {
            temp = new node;
            temp->data = value;
            temp->left = temp->right = NULL;
            h = 0;
            temp->lh = h;
            n_count++;
            root = temp;
            return;
        }
        if(temp->left != NULL)
            insert(temp->left, value);

        if(temp->left != NULL && temp->right == NULL)
        {
            temp2 = new node;
            temp->right = temp2;
            temp2->data = value;
            temp2->right = temp2->left = NULL;
            temp2->lh = h;
            n_count++;
            flag = false;
            return;
        }
        if(temp->lh == h-1 && flag == true)
        {
            if(temp->left == NULL && temp->right == NULL)
            {
                temp2 = new node;
                temp->left = temp2;
                temp2->data = value;
                temp2->left = temp2->right = NULL;
                h++;
                temp2->lh = h;
                n_count++;
                flag = false;
                return;
            }
        }
        if(n_count == (pow(2,h+1) - 1))
        {
            temp2 = new node;
            temp->left = temp2;
            temp2->data = value;
            temp2->left = temp2->right = NULL;
            h++;
            temp2->lh = h;
            n_count++; 
            flag = false;
            return;
        }
        if(temp->right != NULL)
        {
            insert(temp->right, value);
        }
    }
};
int main()
{
    heap a;
    a.num = 7;
    a.insert(a.root, a.num);
    a.num = 9;
    a.insert(a.root, a.num);
    a.num = 4;
    a.insert(a.root, a.num);
    a.num = 6;
    a.insert(a.root, a.num);
    a.num = 11;
    a.insert(a.root, a.num);
    a.num = 15;
    a.insert(a.root, a.num);
    cout << endl;
    a.travere(a.root);
    return 0;
}